hello paint - citrus iPad / procreate kit

Etsy listing images, 9 boards, 2000 x 2000 px PNG

Upload in filename order. Board 01 is the search thumbnail.

Safe area: measured, not assumed. check_safe_area.py finds each board's real
ink bounding box and compares it to x 200..1800 and y 250..1750, which is what
survives Etsy's 4:5 and 4:3 crops of a 2000 square.

Every board in this folder passes.

From this kit's own shipping files:
  25 colours, 440 pieces, none under a size-0 brush tip
  2400 x 2400 px, 5 files in one zip

What changed on 2026-07-28
--------------------------
The outlines now switch off as well as the numbers. finished-art.png sits at
the BOTTOM of the layer stack, so hiding the line art leaves the right colour
where every line used to be instead of a white hairline. It is still the
reference picture; it just earns its keep twice, which is how the kit stays at
five files and inside Etsy's five-file cap.

  02  replaces "the numbers switch off", now three states
  04  new, the seam close-up
  01, 03, 05  reissued to match
  06  redrawn, the old one ran past Etsy's 4:3 crop line
  07  reissued: the old boards printed the internal working size
      (1640 x 1640), which is smaller than the 2400 x 2400 you actually receive
