hello paint - colorful paper kit
Etsy listing images, 10 boards, 2000 x 2000 px PNG

Upload in filename order. Board 01 is the search thumbnail.

Safe area: every board keeps all its content inside Etsy's 1:1, 4:5 and 4:3
crops, checked by measurement. Only a 16:9 promoted-card crop trims anything,
and nothing designed fits a band that shallow.

From this kit's own shipping files:
  30 colours, 304 pieces, 28 under a size-0 brush tip
  84 pages across 5 PDFs
