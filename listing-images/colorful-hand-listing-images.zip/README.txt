hello paint - colorful paper kit

Etsy listing images, 13 boards, 2000 x 2000 px PNG

Upload in filename order. Board 01 is the search thumbnail.

Safe area: measured, not assumed. check_safe_area.py finds each board's real
ink bounding box and compares it to x 200..1800 and y 250..1750, which is what
survives Etsy's 4:5 and 4:3 crops of a 2000 square.

Every board in this folder passes.

From this kit's own shipping files:
  30 colours, 304 pieces, 28 under a size-0 brush tip
  87 pages across 5 PDFs

What changed on 2026-07-29
--------------------------
A design pass over the boards that were carrying dead space or saying a thing
twice. Nothing about the kit itself changed.

  06  rebuilt: each page is now shown whole AND zoomed into the same region,
      with the crop's own box drawn on the sheet. At 430px a numbered page and
      a faint one look identical, which is what the old board showed.
  07  rebuilt: three drawn icons, a footnote each, and "nothing to mix" moved
      into a band. It was three small cards in an empty field.
  09  rebuilt: deep teal instead of pale mint, and the three steps are the
      "how it's made" disclosure in plain words.
  05  the ohuhu column no longer prints "320" above "320 colours", and the
      provenance line names what the 947 colours are.
  01, 08  the pale blue tint on the dark boards is now a soft teal.

What changed on 2026-07-28
--------------------------
The swatch card carries the marker and pencil match now: every colour in the
kit, with the closest colour in Ohuhu 320, Copic, Prismacolor Premier and
Faber-Castell Polychromos, by code and by name. That is what board 05 shows,
and it is why the page count went up.
