hello paint - kiwi iPad / procreate kit
Etsy listing images, 8 boards, 2000 x 2000 px PNG

Upload in filename order. Board 01 is the search thumbnail.

  01  hero
  02  numbers-disappear
  03  colour-drop
  04  whats-in-the-zip
  05  the-palette
  06  the-honest-bit
  07  works-in
  08  send-your-own-photo

Verified from this kit's own shipping files:
  19 colours, 410 pieces, 8 under a size-0 brush tip
  1640 x 2050 px, 5 files in one zip
