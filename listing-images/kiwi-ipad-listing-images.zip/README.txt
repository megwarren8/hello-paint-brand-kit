hello paint - kiwi iPad / procreate kit

Etsy listing images, 14 boards, 2000 x 2000 px PNG

Upload in filename order. Board 01 is the search thumbnail.

Safe area: measured, not assumed. check_safe_area.py finds each board's real
ink bounding box and compares it to x 200..1800 and y 250..1750, which is what
survives Etsy's 4:5 and 4:3 crops of a 2000 square.

Every board in this folder passes.

From this kit's own shipping files:
  19 colours, 410 pieces, 8 under a size-0 brush tip
  2400 x 3000 px, 5 files in one zip

What changed on 2026-07-29
--------------------------
  08  was "works in", a chip list with two thirds of the board empty. It is
      the maker's page now: the four steps of how the kit is actually made.
      The old file is RETIRED, not left in the folder.
  07  the app chips moved here, which is where that fact belongs and which
      fills the hole the board had under its numbers.
  01, 03, 06  the pale blue tint is now a soft teal. The panel images are
      byte-identical to the ones that shipped: only the text colour moved.

What changed on 2026-07-28
--------------------------
The outlines now switch off as well as the numbers. finished-art.png sits at
the BOTTOM of the layer stack, so hiding the line art leaves the right colour
where every line used to be instead of a white hairline. It is still the
reference picture; it just earns its keep twice, which is how the kit stays at
five files and inside Etsy's five-file cap.

  02  replaces "the numbers switch off", now three states
  04  new, the seam close-up
  01, 03, 05  reissued to match
  06  redrawn, the old one ran past Etsy's 4:3 crop line
  07  reissued: the old boards printed the internal working size
      (1640 x 2050), which is smaller than the 2400 x 3000 you actually receive
