hello paint - kiwi paper kit

Etsy listing images, 10 boards, 2000 x 2000 px PNG

Upload in filename order. Board 01 is the search thumbnail.

Safe area: measured, not assumed. check_safe_area.py finds each board's real
ink bounding box and compares it to x 200..1800 and y 250..1750, which is what
survives Etsy's 4:5 and 4:3 crops of a 2000 square.

Every board in this folder passes.

From this kit's own shipping files:
  19 colours, 410 pieces, 8 under a size-0 brush tip
  62 pages across 5 PDFs

What changed on 2026-07-28
--------------------------
The swatch card carries the marker and pencil match now: every colour in the
kit, with the closest colour in Ohuhu 320, Copic, Prismacolor Premier and
Faber-Castell Polychromos, by code and by name. That is what board 05 shows,
and it is why the page count went up.

  05  replaces "every colour, measured", now the real match table
  02  the swatch card card rewritten, and the page count is current
  08  page count is current
  03  rebuilt: it used to exist as a PNG only, so cappy and citrus never had it
