hello paint - kiwi paper kit
Etsy listing images, 10 boards, 2000 x 2000 px PNG

Upload in filename order. Board 01 is the search thumbnail.

  01  hero
  02  whats-in-your-kit
  03  one-colour-at-a-time
  04  eighteen-outlines
  05  every-colour-measured
  06  markers-are-see-through
  07  print-it-and-go
  08  the-honest-bit
  09  made-by-megan
  10  send-your-own-photo

Verified from this kit's own shipping files:
  19 colours, 410 pieces, 8 under a size-0 brush tip
  61 pages across 5 PDFs
